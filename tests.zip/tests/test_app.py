"""Streamlit integration tests: the page must run with and without a model."""

from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from model import config

APP = str(Path(__file__).resolve().parents[1] / "app" / "app.py")


def _run(monkeypatch, model_dir):
    monkeypatch.setenv(config.MODEL_DIR_ENV, str(model_dir))
    at = AppTest.from_file(APP, default_timeout=120)
    at.run()
    assert not at.exception, at.exception
    return at


def _all_text(at):
    parts = [m.value for m in at.markdown] + [c.value for c in at.caption]
    parts += [i.value for i in at.info] + [w.value for w in at.warning]
    return "\n".join(parts)


def test_app_falls_back_without_model(monkeypatch, tmp_path):
    at = _run(monkeypatch, tmp_path)
    text = _all_text(at)
    assert "not available yet" in text
    assert "Contributing factors" in text  # rule-based fallback still shown


def test_app_uses_model_and_shows_shap(monkeypatch, synthetic_model_dir):
    at = _run(monkeypatch, synthetic_model_dir)
    text = _all_text(at)
    assert "synthetic data" in text
    assert "Forecast Soil moisture in 3 days" in text
    assert "(SHAP)" in text
    assert len(at.slider) == 4


def test_app_arabic_with_model(monkeypatch, synthetic_model_dir):
    monkeypatch.setenv(config.MODEL_DIR_ENV, str(synthetic_model_dir))
    at = AppTest.from_file(APP, default_timeout=120)
    at.run()
    at.radio(key="lang_choice").set_value("العربية").run()
    assert not at.exception, at.exception
    assert "SHAP" in _all_text(at)


@pytest.mark.parametrize("soil", [0, 100])
def test_app_slider_extremes(monkeypatch, synthetic_model_dir, soil):
    at = _run(monkeypatch, synthetic_model_dir)
    at.slider[0].set_value(soil).run()
    assert not at.exception, at.exception
