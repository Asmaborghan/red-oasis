"""
Shared settings for the Red Oasis AI component.

Everything that training, prediction and the website must agree on lives
here: feature names, units, valid ranges, the forecast target, and where
the saved model is stored. Edit COLUMN_ALIASES once the real merged CSV
is available so its column names map onto the canonical names below.
"""

from __future__ import annotations

import os
from pathlib import Path

# ----------------------------------------------------------------------
# Paths (relative to this file, so nothing is machine-specific)
# ----------------------------------------------------------------------

PACKAGE_DIR = Path(__file__).resolve().parent
DEFAULT_MODEL_DIR = PACKAGE_DIR / "artifacts"

# Lets the website or tests point at another model folder, e.g. the
# synthetic interface-test model, without touching the real one.
MODEL_DIR_ENV = "RED_OASIS_MODEL_DIR"


def model_dir() -> Path:
    override = os.environ.get(MODEL_DIR_ENV)
    return Path(override) if override else DEFAULT_MODEL_DIR


MODEL_FILE = "model.joblib"
METADATA_FILE = "metadata.json"
EVALUATION_FILE = "evaluation.json"

# ----------------------------------------------------------------------
# Model input features (canonical names used by predict())
# ----------------------------------------------------------------------
# min/max are hard validity limits: values outside them are rejected.

FEATURES = {
    "soil_moisture_pct": {
        "label": "Soil moisture",
        "unit": "% volumetric (SMAP m3/m3 x 100)",
        "min": 0.0,
        "max": 100.0,
        "source": "SMAP",
    },
    "ndvi": {
        "label": "Vegetation index (NDVI)",
        "unit": "unitless, -1 to 1",
        "min": -1.0,
        "max": 1.0,
        "source": "MODIS / VIIRS",
    },
    "rainfall_7d_mm": {
        "label": "Rainfall, last 7 days",
        "unit": "mm (sum of the previous 7 daily totals)",
        "min": 0.0,
        "max": 1000.0,
        "source": "GPM IMERG",
    },
    "temperature_c": {
        "label": "Air temperature",
        "unit": "deg C (daily mean)",
        "min": -30.0,
        "max": 65.0,
        "source": "NASA POWER",
    },
}
FEATURE_ORDER = list(FEATURES)

# Without current soil moisture a soil-moisture forecast is meaningless,
# so it may never be filled in automatically. Other inputs may be
# imputed with the training median, and the result says so.
REQUIRED_FEATURES = {"soil_moisture_pct"}

# ----------------------------------------------------------------------
# Forecast targets
# ----------------------------------------------------------------------
# The model forecasts the value of an observed variable `horizon_days`
# ahead. This is a real, measurable target, so no labels are invented.
# Soil moisture is the default; NDVI is offered because a 250 m MODIS
# pixel fits the ~21.6 ha grove better than a ~9 km SMAP pixel.

TARGETS = {
    "soil_moisture_pct": {
        "label": "Soil moisture",
        "unit": "% volumetric",
        "default_horizon_days": 3,
        # Threshold names in the website's THRESHOLDS dict.
        "dry_key": "soil_dry",
        "moderate_key": "soil_moderate",
    },
    "ndvi": {
        "label": "Vegetation index (NDVI)",
        "unit": "unitless",
        "default_horizon_days": 16,
        "dry_key": "ndvi_low",
        "moderate_key": None,
    },
}
DEFAULT_TARGET = "soil_moisture_pct"

# Fallback thresholds, copied from app/app.py. They are illustrative and
# NOT agronomically validated; the website passes its own values in.
DEFAULT_THRESHOLDS = {
    "soil_dry": 30.0,
    "soil_moderate": 45.0,
    "ndvi_low": 0.30,
}

# ----------------------------------------------------------------------
# Raw CSV handling (for Amna's merged dataset)
# ----------------------------------------------------------------------
# Canonical raw variable -> accepted column names (case-insensitive).
# TODO (Yaqeen): confirm against the real CSV with
#   python -m model.train --data <file> --inspect

COLUMN_ALIASES = {
    "date": ["date", "time", "datetime", "day"],
    "site": ["site", "site_id", "location", "pixel_id"],
    "soil_moisture": ["soil_moisture", "smap_sm", "smap", "sm", "soil_moisture_am"],
    "ndvi": ["ndvi", "modis_ndvi", "viirs_ndvi"],
    "rainfall": ["rainfall", "rainfall_mm", "precipitation", "precip", "gpm_precip", "imerg"],
    "temperature": ["temperature", "temperature_c", "t2m", "temp", "air_temperature"],
}

# Units of the raw CSV columns. SMAP is distributed as m3/m3.
RAW_UNITS = {
    "soil_moisture": "m3/m3",  # or "pct"
    "temperature": "C",        # or "K"
}

# Gap filling applied after resampling to one row per day.
NDVI_FFILL_DAYS = 16          # MODIS/VIIRS composites are 8-16 days
TEMPERATURE_INTERP_DAYS = 3
RAIN_WINDOW_DAYS = 7
RAIN_MIN_DAYS = 5             # need at least 5 of the 7 daily totals

# ----------------------------------------------------------------------
# Evaluation rules
# ----------------------------------------------------------------------

TEST_FRACTION = 0.2           # final, most recent 20% of dates
MIN_TRAIN_ROWS = 100
MIN_TEST_ROWS = 30
CV_SPLITS = 5

RANDOM_STATE = 42
