"""
Load the merged environmental CSV and turn it into model features and a
forecast target.

The same feature definitions are used at prediction time (see
config.FEATURES), so the website must pass values in the same units.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from . import config


class DataError(ValueError):
    """The CSV cannot be used for training as it is."""


def _match_columns(columns) -> dict[str, str]:
    """Map canonical raw names to the actual CSV column names."""
    lower = {c.strip().lower(): c for c in columns}
    found = {}
    for canonical, aliases in config.COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in lower:
                found[canonical] = lower[alias]
                break
    return found


def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Rename recognised columns to canonical names and parse dates."""
    mapping = _match_columns(df.columns)
    if "date" not in mapping:
        raise DataError(
            f"No date column found. Columns are: {list(df.columns)}. "
            "Add the name to config.COLUMN_ALIASES['date']."
        )
    df = df.rename(columns={v: k for k, v in mapping.items()})
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    if df["date"].isna().any():
        raise DataError(f"{int(df['date'].isna().sum())} rows have an unreadable date.")
    return df


def load_raw(path: str | Path) -> pd.DataFrame:
    """Read the CSV and rename recognised columns to canonical names."""
    return standardize_columns(pd.read_csv(path))


def inspect(path: str | Path) -> str:
    """Return a plain-text report on what the CSV actually contains."""
    raw = pd.read_csv(path)
    mapping = _match_columns(raw.columns)
    lines = [f"File: {path}", f"Rows: {len(raw)}", "", "Columns:"]
    for col in raw.columns:
        s = raw[col]
        desc = f"  {col!r}: dtype={s.dtype}, missing={s.isna().mean():.1%}"
        if pd.api.types.is_numeric_dtype(s) and s.notna().any():
            desc += f", min={s.min():.4g}, max={s.max():.4g}, mean={s.mean():.4g}"
        lines.append(desc)
    lines += ["", "Recognised as:"]
    for canonical in config.COLUMN_ALIASES:
        lines.append(f"  {canonical:<14} -> {mapping.get(canonical, 'NOT FOUND')}")
    if "date" in mapping:
        d = pd.to_datetime(raw[mapping["date"]], errors="coerce").dropna()
        if len(d):
            step = d.sort_values().diff().median()
            lines += ["", f"Dates: {d.min().date()} to {d.max().date()}, median step {step}"]
    if "soil_moisture" in mapping:
        mx = pd.to_numeric(raw[mapping["soil_moisture"]], errors="coerce").max()
        unit = config.RAW_UNITS["soil_moisture"]
        if unit == "m3/m3" and mx > 1:
            lines.append("WARNING: soil moisture > 1 but RAW_UNITS says m3/m3. Is it already %?")
        if unit == "pct" and mx <= 1:
            lines.append("WARNING: soil moisture <= 1 but RAW_UNITS says pct. Is it m3/m3?")
    lines += [
        "",
        "Label check: this pipeline does not need stress labels. It forecasts an",
        "observed variable, so no target is invented. If verified crop-stress or",
        "irrigation labels exist, report them before training a classifier.",
    ]
    return "\n".join(lines)


def _daily_site_frame(g: pd.DataFrame) -> pd.DataFrame:
    """Resample one site's records to one row per calendar day."""
    g = g.set_index("date").sort_index()
    agg = {}
    for col in ("soil_moisture", "ndvi", "temperature"):
        if col in g:
            agg[col] = g[col].resample("D").mean()
    if "rainfall" in g:
        # min_count=1 keeps a missing day as NaN instead of 0 mm.
        agg["rainfall"] = g["rainfall"].resample("D").sum(min_count=1)
    return pd.DataFrame(agg)


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Return one row per site-day with the canonical model features.

    Missing values stay NaN; the model's imputer handles them and the
    training report counts them. Nothing is filled with made-up values.
    """
    df = standardize_columns(df)
    missing = [c for c in ("soil_moisture", "ndvi", "rainfall", "temperature") if c not in df]
    if "soil_moisture" in missing:
        raise DataError("Soil moisture column is required and was not found.")

    df = df.copy()
    for col in ("soil_moisture", "ndvi", "rainfall", "temperature"):
        if col in df:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        else:
            df[col] = np.nan

    if config.RAW_UNITS["soil_moisture"] == "m3/m3":
        df["soil_moisture"] = df["soil_moisture"] * 100.0
    if config.RAW_UNITS["temperature"] == "K":
        df["temperature"] = df["temperature"] - 273.15

    if "site" not in df:
        df["site"] = "site_1"

    frames = []
    for site, g in df.groupby("site", sort=True):
        d = _daily_site_frame(g)
        out = pd.DataFrame(index=d.index)
        out["soil_moisture_pct"] = d["soil_moisture"]
        out["ndvi"] = d["ndvi"].ffill(limit=config.NDVI_FFILL_DAYS)
        out["rainfall_7d_mm"] = (
            d["rainfall"]
            .rolling(config.RAIN_WINDOW_DAYS, min_periods=config.RAIN_MIN_DAYS)
            .sum()
        )
        out["temperature_c"] = d["temperature"].interpolate(
            limit=config.TEMPERATURE_INTERP_DAYS, limit_area="inside"
        )
        out["site"] = site
        frames.append(out.reset_index())
    feats = pd.concat(frames, ignore_index=True)
    feats.attrs["missing_raw_columns"] = missing
    return feats


def add_target(feats: pd.DataFrame, target: str, horizon_days: int) -> pd.DataFrame:
    """Add `target_future`: the target variable `horizon_days` later.

    Rows without a current soil-moisture reading or without a future
    target value are dropped, never filled.
    """
    if target not in config.TARGETS:
        raise DataError(f"Unknown target {target!r}. Choose from {list(config.TARGETS)}.")
    if horizon_days < 1:
        raise DataError("horizon_days must be at least 1.")
    parts = []
    for _, g in feats.groupby("site", sort=True):
        g = g.sort_values("date").copy()
        # Rows are daily and contiguous per site, so shift = days ahead.
        g["target_future"] = g[target].shift(-horizon_days)
        parts.append(g)
    out = pd.concat(parts, ignore_index=True)
    out = out.dropna(subset=["soil_moisture_pct", "target_future"])
    return out.sort_values(["date", "site"]).reset_index(drop=True)
