# Red Oasis — AI component (`model/`)

Owner: Yaqeen (AI/ML). This folder holds the forecast model, the `predict()`
function the website calls, SHAP explanations, and the evaluation.

## Status

| Part | Status |
|---|---|
| Training pipeline (`train.py`, `data.py`) | Done, tested on synthetic data |
| `predict()` (`predict.py`) | Done, tested |
| SHAP explanations (`explain.py`) | Done, tested (contributions add up to the prediction) |
| Evaluation method | Done: chronological hold-out + baselines |
| **Trained model on real data** | **Not yet — waiting for the merged NASA CSV** |
| **Real evaluation metrics** | **Not yet — none exist until the real data arrives** |

Until a real model is trained, `model/artifacts/` is empty, `predict()`
returns `status="model_unavailable"`, and the website shows its original
rule-based demo with a message saying so.

## What the model does

**Task: regression (forecasting).** From today's conditions, forecast
**SMAP soil moisture (% volumetric) 3 days ahead**.

Why this target: no verified crop-stress or irrigation labels exist yet,
and inventing labels from our own rules would make any accuracy score
meaningless (the model would just re-learn our rules). A future soil
moisture value is a *real observation*, so the score is honest.

The irrigation level (`irrigate` / `monitor` / `none`) is then derived by
comparing the forecast with the website's `THRESHOLDS`. Those thresholds
are still illustrative (Shareefa's TODO), so the level is not a validated
agronomic recommendation.

Alternative target: `--target ndvi` forecasts NDVI 16 days ahead. A 250 m
MODIS pixel fits the ~21.6 ha grove better than a ~9 km SMAP pixel, so use
this if SMAP turns out to be dominated by the surrounding desert.

### Inputs (`predict()` expects these names and units)

| Name | Unit | Source | Required |
|---|---|---|---|
| `soil_moisture_pct` | % volumetric (SMAP m³/m³ × 100) | SMAP | yes |
| `ndvi` | unitless, −1 to 1 | MODIS / VIIRS | no* |
| `rainfall_7d_mm` | mm, sum of previous 7 daily totals | GPM IMERG | no* |
| `temperature_c` | °C, daily mean | NASA POWER | no* |

\* Missing optional inputs are filled with the training median and the
result lists them in `imputed` and `warnings`. Values outside the hard
limits in `config.FEATURES` are rejected.

### Algorithm: Random Forest regressor (scikit-learn)

- Works well on small tabular datasets (one site, a few years of daily
  data) with little tuning.
- Captures non-linear effects (e.g. heat matters more when soil is dry).
- Exact, fast SHAP values via `shap.TreeExplainer`.
- Small file (~0.3 MB), loads in well under a second.

Preprocessing is a median imputer inside the same scikit-learn `Pipeline`,
so training and prediction always use identical preprocessing.

## How the evaluation works

1. The most recent 20% of dates are held out as the **test set**.
2. A gap of `horizon` days separates training from test, so no training
   target overlaps the test period (prevents leakage).
3. The model is compared on the test set with two baselines:
   - **persistence**: "in 3 days it will be the same as today"
   - **training mean**: always predict the average
4. Metrics: **MAE** (average error, in % soil moisture), **RMSE** (punishes
   big errors more), **R²** (1 = perfect, 0 = no better than the average).
5. `skill_vs_persistence` = 1 − MAE_model / MAE_persistence. Above 0 means
   the model beats the simple "no change" guess. **If it is not above 0,
   the model adds nothing and we should say so.**
6. A `TimeSeriesSplit` cross-validation inside the training period is
   also reported to show how stable the error is.
7. After evaluation, the saved model is refit on all rows.

Everything is written to `model/artifacts/evaluation.json`. If there are
fewer than 100 training or 30 test rows, no model is saved and the file
says `"status": "insufficient_data"`.

## Commands (run from the repository root)

```bash
pip install -r requirements-dev.txt

# 1. Check what the real CSV contains (columns, units, gaps, dates)
python -m model.train --data data/merged.csv --inspect

# 2. Train + evaluate (writes model/artifacts/)
python -m model.train --data data/merged.csv

# 3. Try predict() from the command line
python -m model.predict

# 4. Run all tests
python -m pytest -q

# 5. Run the website
streamlit run app/app.py
```

Interface test before the real data exists (SYNTHETIC — never present as results):

```bash
python -m model.train --synthetic-demo
# PowerShell:
$env:RED_OASIS_MODEL_DIR = "model/artifacts_synthetic_demo"; streamlit run app/app.py
# macOS/Linux:
RED_OASIS_MODEL_DIR=model/artifacts_synthetic_demo streamlit run app/app.py
```

The synthetic model goes to `model/artifacts_synthetic_demo/`, which is
git-ignored, and the website shows a warning banner whenever it is used.

## Expected CSV format (for Amna's merged file)

One row per date (and per site, if there are several), for example:

```text
date,soil_moisture,ndvi,rainfall_mm,temperature_c
2023-01-01,0.112,0.41,0.0,22.3
```

- Column names are matched case-insensitively using `COLUMN_ALIASES` in
  `config.py`. Add names there if Amna's file uses different ones.
- Set `RAW_UNITS` in `config.py`: soil moisture `m3/m3` (SMAP default) or
  `pct`; temperature `C` or `K`.
- Gaps should be left empty, never filled with 0. A missing rain day is
  not the same as 0 mm.
- An optional `site` column is supported.
- For a meaningful evaluation, aim for at least ~1–2 years of data.

## Calling it from Streamlit

```python
from model.predict import predict, model_status

result = predict(
    {"soil_moisture_pct": 12.5, "ndvi": 0.41, "rainfall_7d_mm": 0.0, "temperature_c": 38.0},
    thresholds=THRESHOLDS,   # the website's own thresholds
)
result["status"]                    # "ok" | "model_unavailable" | "invalid_input" | "error"
result["prediction"]["value"]       # forecast, in result["prediction"]["unit"]
result["recommendation"]["level"]   # "irrigate" | "monitor" | "none"
result["explanation"]["contributions"]  # SHAP, ranked
result["explanation"]["summary"]    # plain-English text
result["warnings"]                  # always show these
model_status()["evaluation"]        # contents of evaluation.json
```

`predict()` never raises. It always returns a dict with the same keys.

## Limits to state honestly

- SMAP (~9 km) is regional context, not a field measurement of the grove.
  Falaj irrigation inside the grove is largely invisible to it.
- SHAP shows how the model uses each input, not what physically causes
  soil moisture to change.
- The model does not predict crop stress directly. Doing that needs
  verified labels (e.g. ECOSTRESS ESI, grower logs or field observations).
- Mars mode does not use this model. Mars settings are experimental
  concepts, not validated operating values.

## Files

| File | Purpose |
|---|---|
| `config.py` | Feature names, units, limits, target, paths, CSV column aliases |
| `data.py` | Load/inspect CSV, daily resampling, feature building, target |
| `train.py` | Train, evaluate, save `model.joblib`, `metadata.json`, `evaluation.json` |
| `predict.py` | `predict()`, `load_model()`, `model_status()`, input validation |
| `explain.py` | SHAP per-prediction contributions, global importance, text summary |
| `synthetic.py` | Synthetic data for software tests only |
| `artifacts/` | Saved real model (empty until trained) |
