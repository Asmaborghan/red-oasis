"""
Train, evaluate and save the Red Oasis forecast model.

Usage (from the repository root):

    # 1. Look at the real CSV first: columns, units, gaps, date range
    python -m model.train --data data/merged.csv --inspect

    # 2. Train on it (writes model/artifacts/)
    python -m model.train --data data/merged.csv

    # Interface test only: train on SYNTHETIC data into a separate,
    # git-ignored folder. Never present its scores as real results.
    python -m model.train --synthetic-demo

Task: regression. Forecast an observed variable (default: SMAP soil
moisture, %) `horizon` days ahead from today's soil moisture, NDVI,
7-day rainfall and air temperature.

Evaluation: the most recent 20% of dates are held out as a test set,
with a gap of `horizon` days so no training target overlaps the test
period. The model is compared with two simple baselines. After
evaluation, the saved model is refit on all rows.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import TimeSeriesSplit
from sklearn.pipeline import Pipeline

from . import config, data, explain


def build_pipeline() -> Pipeline:
    return Pipeline([
        # keep_empty_features keeps column positions stable for SHAP.
        ("imputer", SimpleImputer(strategy="median", keep_empty_features=True)),
        ("model", RandomForestRegressor(
            n_estimators=200,
            max_depth=12,
            min_samples_leaf=5,
            n_jobs=-1,
            random_state=config.RANDOM_STATE,
        )),
    ])


def _metrics(y_true, y_pred) -> dict:
    return {
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "r2": float(r2_score(y_true, y_pred)),
    }


def _persistence(df: pd.DataFrame, target: str) -> pd.Series:
    """Baseline: 'the value in `horizon` days equals the value today'."""
    return df[target]


def chronological_split(df: pd.DataFrame, horizon_days: int):
    """Hold out the latest TEST_FRACTION of dates, with a `horizon` gap."""
    dates = np.sort(df["date"].unique())
    cutoff = dates[int(len(dates) * (1 - config.TEST_FRACTION))]
    train = df[df["date"] < cutoff - pd.Timedelta(days=horizon_days)]
    test = df[df["date"] >= cutoff]
    return train, test, pd.Timestamp(cutoff)


def evaluate(df: pd.DataFrame, target: str, horizon_days: int) -> dict:
    """Honest held-out evaluation. Returns a dict saved as evaluation.json."""
    train, test, cutoff = chronological_split(df, horizon_days)
    result = {
        "task": "regression (forecast)",
        "target": f"{target} in {horizon_days} days",
        "target_unit": config.TARGETS[target]["unit"],
        "validation": (
            f"Chronological hold-out: train on dates before "
            f"{(cutoff - pd.Timedelta(days=horizon_days)).date()}, test on dates from "
            f"{cutoff.date()} ({horizon_days}-day gap to prevent target leakage)."
        ),
        "n_train": int(len(train)),
        "n_test": int(len(test)),
    }
    if len(train) < config.MIN_TRAIN_ROWS or len(test) < config.MIN_TEST_ROWS:
        result["status"] = "insufficient_data"
        result["message"] = (
            f"Need at least {config.MIN_TRAIN_ROWS} training and {config.MIN_TEST_ROWS} "
            f"test rows with a current soil-moisture value and a future target value."
        )
        return result

    X_cols = config.FEATURE_ORDER
    model = build_pipeline().fit(train[X_cols], train["target_future"])

    # Compare everything on the rows where the persistence baseline exists.
    persist = _persistence(test, target)
    rows = persist.notna()
    y = test.loc[rows, "target_future"]
    result["n_test_compared"] = int(rows.sum())
    result["test_metrics"] = {
        "model": _metrics(y, model.predict(test.loc[rows, X_cols])),
        "baseline_persistence": _metrics(y, persist[rows]),
        "baseline_training_mean": _metrics(y, np.full(len(y), train["target_future"].mean())),
    }
    m, p = result["test_metrics"]["model"], result["test_metrics"]["baseline_persistence"]
    result["skill_vs_persistence"] = float(1 - m["mae"] / p["mae"]) if p["mae"] > 0 else None

    # Robustness check inside the training period only.
    # Rows are sorted by date, one per site-day, so the gap is in rows.
    n_splits = min(config.CV_SPLITS, max(2, len(train) // 50))
    gap_rows = horizon_days * train["site"].nunique()
    tscv = TimeSeriesSplit(n_splits=n_splits, gap=gap_rows)
    cv_model, cv_persist = [], []
    for tr_idx, va_idx in tscv.split(train):
        tr, va = train.iloc[tr_idx], train.iloc[va_idx]
        va = va[_persistence(va, target).notna()]
        if len(va) == 0:
            continue
        fold = build_pipeline().fit(tr[X_cols], tr["target_future"])
        cv_model.append(mean_absolute_error(va["target_future"], fold.predict(va[X_cols])))
        cv_persist.append(mean_absolute_error(va["target_future"], _persistence(va, target)))
    result["cv_mae_training_period"] = {
        "method": f"TimeSeriesSplit(n_splits={n_splits}, gap={gap_rows} rows)",
        "model_mean": float(np.mean(cv_model)) if cv_model else None,
        "model_std": float(np.std(cv_model)) if cv_model else None,
        "persistence_mean": float(np.mean(cv_persist)) if cv_persist else None,
    }
    result["status"] = "ok"
    return result


def train(raw: pd.DataFrame, target: str, horizon_days: int, out_dir: Path,
          data_source: str, is_synthetic: bool) -> dict:
    feats = data.build_features(raw)
    df = data.add_target(feats, target, horizon_days)

    missing_share = {c: float(df[c].isna().mean()) for c in config.FEATURE_ORDER}
    empty = [c for c, share in missing_share.items() if share == 1.0]
    if empty:
        raise data.DataError(f"These features have no values at all: {empty}.")

    evaluation = evaluate(df, target, horizon_days)
    evaluation.update({
        "data_source": data_source,
        "is_synthetic": is_synthetic,
        "feature_missing_share": missing_share,
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    })
    if is_synthetic:
        evaluation["warning"] = (
            "Computed on SYNTHETIC data to test the software. "
            "This is NOT a measure of real predictive performance."
        )

    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / config.EVALUATION_FILE).write_text(json.dumps(evaluation, indent=2))
    if evaluation["status"] != "ok":
        # No evaluated model -> no saved model. Remove any stale one.
        (out_dir / config.MODEL_FILE).unlink(missing_ok=True)
        (out_dir / config.METADATA_FILE).unlink(missing_ok=True)
        return evaluation

    X, y = df[config.FEATURE_ORDER], df["target_future"]
    pipeline = build_pipeline().fit(X, y)

    import shap
    import sklearn

    metadata = {
        "model_type": "RandomForestRegressor (scikit-learn) with median imputation",
        "target": target,
        "target_label": config.TARGETS[target]["label"],
        "target_unit": config.TARGETS[target]["unit"],
        "horizon_days": horizon_days,
        "features": {k: dict(v) for k, v in config.FEATURES.items()},
        "feature_order": config.FEATURE_ORDER,
        "training_range": {
            c: {"min": float(X[c].min()), "max": float(X[c].max())} for c in config.FEATURE_ORDER
        },
        "training_median": dict(zip(
            config.FEATURE_ORDER,
            map(float, pipeline.named_steps["imputer"].statistics_),
        )),
        "n_rows": int(len(df)),
        "date_range": [str(df["date"].min().date()), str(df["date"].max().date())],
        "data_source": data_source,
        "is_synthetic": is_synthetic,
        "global_importance": explain.global_importance(pipeline, X),
        "trained_at": evaluation["created_at"],
        "library_versions": {"scikit-learn": sklearn.__version__, "shap": shap.__version__},
        "note": "Saved model is refit on all rows after the held-out evaluation.",
    }
    joblib.dump(pipeline, out_dir / config.MODEL_FILE, compress=3)
    (out_dir / config.METADATA_FILE).write_text(json.dumps(metadata, indent=2))
    return evaluation


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Train the Red Oasis forecast model.")
    p.add_argument("--data", type=Path, help="Merged CSV with date + SMAP/NDVI/rain/temperature")
    p.add_argument("--inspect", action="store_true", help="Only report what the CSV contains")
    p.add_argument("--target", default=config.DEFAULT_TARGET, choices=list(config.TARGETS))
    p.add_argument("--horizon", type=int, help="Days ahead to forecast")
    p.add_argument("--out", type=Path, help="Output folder (default: model/artifacts)")
    p.add_argument("--synthetic-demo", action="store_true",
                   help="Train on SYNTHETIC data for interface testing only")
    args = p.parse_args(argv)

    horizon = args.horizon or config.TARGETS[args.target]["default_horizon_days"]

    if args.synthetic_demo:
        from .synthetic import SYNTHETIC_NOTICE, make_synthetic_raw

        raw = make_synthetic_raw()
        out = args.out or config.PACKAGE_DIR / "artifacts_synthetic_demo"
        source, synthetic = SYNTHETIC_NOTICE, True
    else:
        if not args.data:
            p.error("--data is required (or use --synthetic-demo for an interface test)")
        if args.inspect:
            print(data.inspect(args.data))
            return 0
        raw = data.load_raw(args.data)
        out = args.out or config.DEFAULT_MODEL_DIR
        source, synthetic = f"CSV: {args.data.name}", False

    try:
        evaluation = train(raw, args.target, horizon, out, source, synthetic)
    except data.DataError as exc:
        print(f"Data problem: {exc}", file=sys.stderr)
        return 2

    print(json.dumps(evaluation, indent=2))
    print(f"\nWrote results to {out}")
    return 0 if evaluation["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
